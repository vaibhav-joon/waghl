/**
 * Apply the WAGHL interactive-message extension to the CURRENT repository.
 * It inserts new operations and never replaces your existing node, credentials,
 * package name, README, GitHub Actions workflow, or release configuration.
 * Run from the root of the Codespaces checkout: node add-interactive.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const root = process.cwd();
const nodePath = path.join(root, 'nodes/Waghl/Waghl.node.ts');
const packagePath = path.join(root, 'package.json');
const snippetsDir = path.join(import.meta.dirname, 'snippets');
const snippet = (name) => fs.readFileSync(path.join(snippetsDir, name), 'utf8');

if (!fs.existsSync(nodePath)) {
  console.error('Could not find nodes/Waghl/Waghl.node.ts. Run this from your repository root.');
  process.exit(1);
}

const original = fs.readFileSync(nodePath, 'utf8');
if (original.includes('sendInteractiveButtons')) {
  console.log('Interactive operations appear to be installed already. No files changed.');
  process.exit(0);
}
if (!original.includes('httpRequestWithAuthentication')) {
  console.error('Your node still uses an older HTTP authentication implementation.');
  console.error('Please apply the previous WAGHL credential-authentication fix first. No changes made.');
  process.exit(1);
}

let next = original;
function replaceOnce(label, oldText, newText) {
  const start = next.indexOf(oldText);
  if (start === -1 || next.indexOf(oldText, start + oldText.length) !== -1) {
    throw new Error(`Could not find ONE safe insertion point for ${label}. No files changed. ` +
      'Your current node may have a different structure; share Waghl.node.ts for a tailored patch.');
  }
  next = next.slice(0, start) + newText + next.slice(start + oldText.length);
}

try {
  replaceOnce('new import', 'export class Waghl implements INodeType {',
    "import { buildInteractivePayload, interactiveResponseFailure } from './interactive';\n\n" +
    'export class Waghl implements INodeType {');
  const operationEnd = "        ],\n        default: 'sendText',";
  replaceOnce('operation options', operationEnd,
    snippet('operation-options.txt') + operationEnd);
  const propertiesEnd = '    ],\n  };\n\n  async execute';
  replaceOnce('interactive form fields', propertiesEnd,
    snippet('fields.txt') + propertiesEnd);
  const unsupportedBranch =
    '        } else {\n          throw new NodeOperationError(this.getNode(), `Unsupported operation: ${operation}`, {';
  replaceOnce('interactive request builders', unsupportedBranch,
    snippet('execution.txt') + unsupportedBranch);
  const responseAnchor = '        returnData.push({\n          json: responseJson,';
  replaceOnce('interactive response validation', responseAnchor,
    snippet('response-validation.txt') + responseAnchor);
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
}

// Only write once every insertion point has been found successfully.
fs.writeFileSync(nodePath, next);
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
pkg.scripts ||= {};
pkg.scripts['test:interactive'] = 'npm run build && node --test test/interactive.test.cjs';
if (pkg.scripts.test === 'npm run lint && npm run build') {
  pkg.scripts.test += ' && node --test test/interactive.test.cjs';
}
fs.writeFileSync(packagePath, JSON.stringify(pkg, null, 2) + '\n');
console.log('Added the three interactive operations to the current Waghl.node.ts.');
console.log('Existing credentials, package name, workflow and unrelated node logic remain unchanged.');
console.log('Next: npm install --package-lock-only && npm ci && npm test && npm pack --dry-run');
