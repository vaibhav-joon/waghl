/**
 * Fix two catch-block lint violations introduced by WAGHL interactive add-on v2.
 * Does not touch credentials, endpoint construction, package metadata or workflows.
 * Run from the project root: node fix-interactive-lint.mjs
 */
import fs from 'node:fs';
import path from 'node:path';

const target = path.join(process.cwd(), 'nodes/Waghl/interactive.ts');
if (!fs.existsSync(target)) {
  console.error(`Not found: ${target}. Run from the WAGHL repository root.`);
  process.exit(1);
}
let source = fs.readFileSync(target, 'utf8');
const fixes = [
  {
    name: 'URL validation',
    old: `  let parsed: URL;\n  try {\n    parsed = new URL(input);\n  } catch {\n    throw new Error(\`\${name} must be a valid HTTP or HTTPS URL\`);\n  }\n  if (!['http:', 'https:'].includes(parsed.protocol)) {`,
    updated: `  let parsed: URL | undefined;\n  try {\n    parsed = new URL(input);\n  } catch {\n    // Report input-validation errors outside catch; the node wraps them in NodeOperationError.\n  }\n  if (!parsed) {\n    throw new Error(\`\${name} must be a valid HTTP or HTTPS URL\`);\n  }\n  if (!['http:', 'https:'].includes(parsed.protocol)) {`,
    already: `  let parsed: URL | undefined;`,
  },
  {
    name: 'JSON validation',
    old: `  if (typeof parsed === 'string') {\n    try {\n      parsed = JSON.parse(parsed);\n    } catch {\n      throw new Error(\`\${name} must contain valid JSON\`);\n    }\n  }`,
    updated: `  if (typeof parsed === 'string') {\n    let jsonInvalid = false;\n    try {\n      parsed = JSON.parse(parsed);\n    } catch {\n      jsonInvalid = true;\n    }\n    if (jsonInvalid) {\n      throw new Error(\`\${name} must contain valid JSON\`);\n    }\n  }`,
    already: `    let jsonInvalid = false;`,
  },
];
let changes = 0;
for (const fix of fixes) {
  if (source.includes(fix.already)) {
    console.log(`${fix.name}: already fixed`);
    continue;
  }
  const index = source.indexOf(fix.old);
  if (index < 0 || source.indexOf(fix.old, index + 1) >= 0) {
    console.error(`${fix.name}: expected snippet not found exactly once. Nothing written.`);
    process.exit(1);
  }
  source = source.replace(fix.old, fix.updated);
  changes++;
}
if (changes) fs.writeFileSync(target, source);
console.log(`Applied ${changes} catch-block fix(es) to ${path.relative(process.cwd(), target)}.`);
console.log('Next: npm run lint:fix && npm test && npm pack --dry-run');
